package com.example.banchile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BanChileApplicationTests {

	@Test
	void contextLoads() {
	}

}
