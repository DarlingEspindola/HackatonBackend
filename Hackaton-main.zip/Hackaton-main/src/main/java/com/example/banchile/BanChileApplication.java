package com.example.banchile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BanChileApplication {

	public static void main(String[] args) {
		SpringApplication.run(BanChileApplication.class, args);
	}

}
